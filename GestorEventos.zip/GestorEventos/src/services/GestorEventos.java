
package services;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;


public class GestorEventos<T extends Comparable<T> & CSVSerializable> implements Gestionable<T>{
    
    private List<T> gestor = new ArrayList<>();

    @Override
    public void agregar(T item) {
        if(item == null)
        {
            throw new IllegalArgumentException("No es un elemento gestionable");
        }
        this.gestor.add(item); 
    }

    @Override
    public void eliminar(int indice) {
        checkRango(indice);
        gestor.remove(indice);
    }

    @Override
    public T obtener(int indice) {
        return gestor.get(indice);
    }

    @Override
    public void limpiar() {
        if(!gestor.isEmpty())
        {
            gestor.clear();
        }
    }

    @Override
    public void ordenar() {
        if(!gestor.isEmpty() && gestor.get(0) instanceof Comparable)
        {
            ordenar((Comparator<T>)Comparator.naturalOrder());
        }
    }

    @Override
    public void ordenar(Comparator<? super T> comparador) {
        gestor.sort(comparador);
    }

    @Override
    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> gestorNuevo = new ArrayList();
        for(T item : gestor)
        {
            if(criterio.test(item))
            {
                gestorNuevo.add(item);
            }
        }    
        return gestorNuevo;
    }

    @Override
    public void mostrarTodos() {
        for(T item : gestor)
        {
            System.out.println(item);
        }
    }

    @Override
    public void guardarEnCSV(String nombreArchivo) throws IOException {
        File archivo = new File(nombreArchivo);
        
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))){ 
            
            bw.write(gestor.get(0).toHeaderCSV());
            for(T item : gestor)
            {
                bw.write(item.toCSV() + "\n");            
            }
        }
    }

    @Override
    public void cargarDesdeCSV(String nombreArchivo, Function<String, T> funcion) throws IOException {
        File archivo = new File(nombreArchivo);
        
        try(BufferedReader br = new BufferedReader(new FileReader(archivo))){
            
            String linea;
            br.readLine();
            while((linea = br.readLine()) != null)
            {
                if(linea.endsWith("\n")){
                    linea = linea.substring(linea.length() - 1);
                }
                
                agregar(funcion.apply(linea));                
            }
            
        }  
    }

    @Override
    public void guardarEnBinario(String path) throws IOException {
        try(ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path)))
        {
            salida.writeObject(gestor);
        }
    }

    
    @Override
    public void cargarDesdeBinario(String path) throws IOException, ClassNotFoundException{
        try(ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path)))
        {
            gestor = (List<T>)entrada.readObject();
        }
    }  
    
    
    private void checkRango(int indice)
    {
        if(indice < 0 || indice >= gestor.size())
        {
            throw new IndexOutOfBoundsException("El elemento es menor a 0 o es mayor al tamaño de la lista");
        }
    }
    
}
