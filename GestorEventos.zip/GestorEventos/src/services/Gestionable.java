
package services;

import java.io.IOException;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

/*
▪ Agregar, eliminar, obtener y limpiar elementos.
▪ Ordenar por criterio natural y personalizado.
▪ Filtrar elementos según un criterio dado.
▪ Guardar y cargar elementos desde archivos binarios.
▪ Guardar y cargar elementos en formato CSV.
▪ Mostrar todos los elementos en consola.

*/


public interface Gestionable<T extends Comparable<T> & CSVSerializable> {
    
    void agregar(T item);
    
    void eliminar(int indice);
    
    T obtener(int indice);
    
    void limpiar();
    
    void ordenar();
    
    void ordenar(Comparator<? super T> comparador);
            
    List<T> filtrar(Predicate<? super T> criterio);
    
    void mostrarTodos();
    
    void guardarEnCSV(String nombreArchivo) throws IOException;
    
    void cargarDesdeCSV(String nombreArchivo, Function<String, T> funcion) throws IOException;
            
    void guardarEnBinario(String path) throws IOException;
    
    void cargarDesdeBinario(String path) throws IOException, ClassNotFoundException;

}
