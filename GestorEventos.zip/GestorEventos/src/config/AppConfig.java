
package config;


public class AppConfig {
    public static final String PATH_FILE = "src/data/";
    public static final String PATH_CSV = PATH_FILE + "eventos.csv";
    public static final String PATH_SER = PATH_FILE + "eventos.dat";
}
