
package model;

import java.io.Serializable;
import java.time.LocalDate;
import services.CSVSerializable;


public class EventoMusical extends Evento implements CSVSerializable, Comparable<EventoMusical>, Serializable{
    private static final long SerialVersionUID = 1L;
    private String artista;
    private GeneroMusical genero;

    public EventoMusical(int id, String nombre, LocalDate fecha, String artista, GeneroMusical genero) {
        super(id, nombre, fecha);
        this.artista = artista;
        this.genero = genero;
    }

    public GeneroMusical getGenero() {
        return genero;
    }
    
    

    @Override
    public String toCSV() {
        return getId() + "," + getNombre() + "," + getFecha() + "," + artista + "," + genero;
    }

    @Override
    public String toHeaderCSV() {
        return "id,nombre,fecha,artista,genero\n";
    }

    public static EventoMusical fromCSV(String datos)
    {
        EventoMusical toReturn = null;
        
        String[] values = datos.split(",");
        if(values.length == 5)
        {
            int id = Integer.parseInt(values[0]);
            String nombre = values[1];
            LocalDate fecha = LocalDate.parse(values[2]);
            String artista = values[3];
            GeneroMusical clase = GeneroMusical.valueOf(values[4]);
            
            toReturn = new EventoMusical(id, nombre, fecha, artista, clase);
            
        }
        
        return toReturn;
    }
   

    @Override
    public int compareTo(EventoMusical e) {
        return getFecha().compareTo(e.getFecha());
    }
    
    
}
